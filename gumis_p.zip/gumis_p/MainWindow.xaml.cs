﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.SqlServer.Server;

namespace gumis_p
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static List<Munkak> munka = new List<Munkak>();
        string[] beolvas;
        public MainWindow()
        {
            InitializeComponent();
            date.Text = DateTime.Today.Date.ToString("yyy.MMM.dd");
            time.Text = DateTime.Now.Hour.ToString();
            beolvas = File.ReadAllLines("enberek.txt");
            Array.Sort(beolvas);
            foreach (var item in beolvas)
            {
                munka.Add(new Munkak(item));
            }
            ElojegyzettMunkak();
            Orak();
        }
        private void Orak()
        {
            timedb.Items.Clear();
            int[] db = new int[6];
            foreach (var item in munka)
            {
                if (item.datum == date.Text)
                {
                    switch (item.ora)
                    {
                        case "06:00":
                            db[0]++;
                            break;
                        case "07:00":
                            db[1]++;
                            break;
                        case "08:00":
                            db[2]++;
                            break;
                        case "09:00":
                            db[3]++;
                            break;
                        case "10:00":
                            db[4]++;
                            break;
                        case "11:00":
                            db[5]++;
                            break;
                        case "12:00":
                            db[6]++;
                            break;
                        case "13:00":
                            db[7]++;
                            break;
                        case "14:00":
                            db[8]++;
                            break;
                        case "15:00":
                            db[9]++;
                            break;
                        case "16:00":
                            db[10]++;
                            break;
                        case "17:00":
                            db[11]++;
                            break;
                        default:
                            break;
                    }
                }
            }
            for (int i = 0; i < db.Length; i++)
            {
                timedb.Items.Add(i + 6 + ": " + db[i] + " db");
            }
        }

        private void ElojegyzettMunkak()
        {
            munkak.Items.Clear();
            foreach (Munkak item in munka)
            {
                if (item.datum == date.Text.ToString())
                {
                    string ki = item.datum + " " + item.ora + " " + item.nev + " " + item.tell + " " + item.rendszam;
                    munkak.Items.Add(item.datum);
                }
            }
        }

        private void kilep_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ment_Click_1(object sender, RoutedEventArgs e)
        {
            if (date.Text != "" && time.Text != "" && name.Text != "" && tell.Text != "" && rendszam.Text != "")
            {
                string kiir = date.Text + ";" + time.Text + ":00;" + name.Text + ";" + tell.Text + ";" + rendszam.Text + "\n";
                File.AppendAllText("emberek.txt", kiir);
                munkak.Items.Clear();
                timedb.Items.Clear();
                MainWindow f = new MainWindow();
                f.Show();
                this.Hide();
                f.Show();
            }
            else
            {
                MessageBox.Show("Valami ühkes");
            }
        }

        private void keres_Click(object sender, RoutedEventArgs e)
        {
            if (time.Text != "")
            {
                ElojegyzettMunkak();
                Orak();
            }
            else if (name.Text != "")
            {
                munkak.Items.Clear();
                Array.Reverse(beolvas);
                foreach (var item in beolvas)
                {
                    if (item.Contains(name.Text))
                    {
                        munkak.Items.Add(item.Replace(";", " "));
                    }
                }
                Array.Sort(beolvas);
            }
            else if (rendszam.Text != "")
            {
                foreach (var item in beolvas)
                {
                    if (item.Contains(rendszam.Text))
                    {
                        munkak.Items.Add(item.Replace(";", " "));
                    }
                }
            }
            else if (rendszam.Text != "")
            {
                foreach (var item in beolvas)
                {
                    if (item.Contains(tell.Text))
                    {
                        munkak.Items.Add(item.Replace(";", " "));
                    }
                }
            }
        }

        private void torol_Click(object sender, RoutedEventArgs e)
        {
            munkak.Items.Clear();
        }
    }
}
